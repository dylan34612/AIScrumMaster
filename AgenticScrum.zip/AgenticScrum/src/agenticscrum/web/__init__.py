"""FastAPI web UI package."""
